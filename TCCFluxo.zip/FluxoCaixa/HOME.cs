﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FluxoCaixa
{
    public partial class HOME : Form
    {

        //Referência da conexão com o banco
        SqlConnection conexao = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Login;Data Source=YUSSUF\\SQLEXPRESS");


        public HOME()
        {
            InitializeComponent();
            txt_usuario.Select();
        }


        private void cAIXAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CAIXA caixa = new CAIXA();
            caixa.ShowDialog();

        }

        private void pRODUTOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PRODUTOS produtos = new PRODUTOS();
            produtos.ShowDialog();


        }
        //Verificação de textboxes vazios
        void verificar()
        {
            if (txt_usuario.Text == "" && txt_senha.Text == "")
            {
                MessageBox.Show("Preencha os campos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Botão Entrar
        private void btn_Entrar_Click(object sender, EventArgs e)
        {
            conexao.Open();//Abre a conexão
            verificar();
            string query = "SELECT * FROM dbo.usuario WHERE Username = '" + txt_usuario.Text + "' AND Password ='" + txt_senha.Text + "' ";
            SqlDataAdapter dp = new SqlDataAdapter(query, conexao);
            DataTable dt = new DataTable();
            dp.Fill(dt);


            if (dt.Rows.Count == 1)
            {
                PRODUTOS produtos = new PRODUTOS();
                this.Hide();
                produtos.Show();
                conexao.Close();
            }

            else
            {
                MessageBox.Show("Usuário ou Senha INCORRETOS!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_usuario.Text = "";//Limpa as textbox depois de serem verificadas.
                txt_senha.Text = "";
                txt_usuario.Select();//Cursor irá sinalizar a primeira textbox(Irrelevante).


            }
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Feito por Yussuf e Gabriel Masi!");
        }
    }

}
