﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FluxoCaixa
{
    public partial class CAIXA : Form
    {
        public CAIXA()
        {
            InitializeComponent();
        }

        SqlConnection sqlCon = null;
        private string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Fluxodb;Data Source=YUSSUF\\SQLEXPRESS";
        private string strSql = string.Empty;
        SqlDataAdapter da = null;
        DataTable datatable = null;


        private void CARREGAR(string caixa)
        {
            try
            {
                sqlCon = new SqlConnection(strCon);
                da = new SqlDataAdapter(caixa, sqlCon);
                datatable = new DataTable();
                da.Fill(datatable);
                datatable.Columns[0].ColumnName = "idproduto";
                datatable.Columns[1].ColumnName = "produto";
                datatable.Columns[2].ColumnName = "marca";
                datatable.Columns[3].ColumnName = "quantidade";
                datatable.Columns[4].ColumnName = "preco";

                dataGridView1.DataSource = datatable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public void ATUALIZAR()
        {
            //Referência de atualização do caixa após o clique no botão.
            strCon = "select idproduto, produto, marca, quantidade, preco from dbo.PRODUTOS order by idproduto ASC";
            SqlCommand com = new SqlCommand(strSql, sqlCon);
            sqlCon.Open();
            SqlDataReader dr = com.ExecuteReader();
            DataTable datatable = new DataTable();
            datatable.Load(dr);
            dataGridView1.DataSource = datatable;



        }
        decimal total;

        private void comprar_Click(object sender, EventArgs e)
        {
            //Parte de compra e cálculo de produtos.
            int id = Convert.ToInt32(txt_pesquisa.Text);
            strSql = "select idproduto, produto, marca, quantidade, preco from dbo.PRODUTOS where idproduto = @id";
            sqlCon = new SqlConnection(strCon);
            SqlCommand com = new SqlCommand(strSql, sqlCon);

            com.Parameters.Add("@id", SqlDbType.Int).Value = int.Parse(txt_pesquisa.Text);

            try
            {
                sqlCon.Open();//Executa a conexão.
                SqlDataReader dr = com.ExecuteReader();//O código lê todos os campos,marca,preco,produto.

                dr.Read();

                label12.Text = Convert.ToString(dr["produto"]);
                label13.Text = Convert.ToString(dr["marca"]);
                label14.Text = Convert.ToString(dr["preco"]);

                int quantidade = int.Parse(txt_quant.Text);
                decimal preco = decimal.Parse(label14.Text);
                total = total + (preco * quantidade);

                label15.Text = total.ToString();//Após o código realizar o cálculo da compra baseado no cadastro+
                //[...]de produtos,é imprimido o total gasto na Label TOTAL.

                txt_pesquisa.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                sqlCon.Close();
            }
        }

        private void txt_pesquisa_KeyUp(object sender, KeyEventArgs e)
        {
            strSql = "select * from dbo.PRODUTOS where idproduto like'"+txt_pesquisa.Text+"' " ;
            CARREGAR(strSql);
        }

        private void atualizar_Click(object sender, EventArgs e)
        {
            //Atualização do caixa após o clique no botão,o caixa atualiza o banco colocando ou tirando produtos.
            strSql = "update dbo.PRODUTOS set quantidade = quantidade - @quantidade where idproduto = @idproduto";
            sqlCon = new SqlConnection(strCon);
            SqlCommand com = new SqlCommand(strSql, sqlCon);

            com.Parameters.Add("@idproduto", SqlDbType.Int).Value = int.Parse(txt_pesquisa.Text);
            com.Parameters.Add("@quantidade", SqlDbType.Int).Value = int.Parse(txt_quant.Text);

            try
            {
                sqlCon.Open();
                com.ExecuteNonQuery();
                MessageBox.Show("PRODUTO VENDIDO COM SUCESSO!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
                ATUALIZAR();
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            PRODUTOS produtos = new PRODUTOS();
            produtos.ShowDialog();

        }
    }
}
