﻿namespace FluxoCaixa
{
    partial class PRODUTOS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_pesquisa = new System.Windows.Forms.TextBox();
            this.txt_preco = new System.Windows.Forms.TextBox();
            this.txt_prod = new System.Windows.Forms.TextBox();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.txt_quant = new System.Windows.Forms.TextBox();
            this.APAGAR = new System.Windows.Forms.Button();
            this.EDITAR = new System.Windows.Forms.Button();
            this.BUSCAR = new System.Windows.Forms.Button();
            this.SALVAR = new System.Windows.Forms.Button();
            this.ADD = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(317, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Preço:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(48, 265);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Marca:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(48, 336);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantidade:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(48, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Produto:";
            // 
            // txt_pesquisa
            // 
            this.txt_pesquisa.Location = new System.Drawing.Point(79, 154);
            this.txt_pesquisa.Name = "txt_pesquisa";
            this.txt_pesquisa.Size = new System.Drawing.Size(171, 20);
            this.txt_pesquisa.TabIndex = 5;
            // 
            // txt_preco
            // 
            this.txt_preco.Location = new System.Drawing.Point(380, 154);
            this.txt_preco.Name = "txt_preco";
            this.txt_preco.Size = new System.Drawing.Size(176, 20);
            this.txt_preco.TabIndex = 6;
            // 
            // txt_prod
            // 
            this.txt_prod.Location = new System.Drawing.Point(150, 203);
            this.txt_prod.Name = "txt_prod";
            this.txt_prod.Size = new System.Drawing.Size(406, 20);
            this.txt_prod.TabIndex = 7;
            // 
            // txt_marca
            // 
            this.txt_marca.Location = new System.Drawing.Point(150, 264);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.Size = new System.Drawing.Size(406, 20);
            this.txt_marca.TabIndex = 8;
            // 
            // txt_quant
            // 
            this.txt_quant.Location = new System.Drawing.Point(150, 335);
            this.txt_quant.Name = "txt_quant";
            this.txt_quant.Size = new System.Drawing.Size(406, 20);
            this.txt_quant.TabIndex = 9;
            // 
            // APAGAR
            // 
            this.APAGAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.APAGAR.Image = global::FluxoCaixa.Properties.Resources.icons8_apagar_para_sempre_48;
            this.APAGAR.Location = new System.Drawing.Point(472, 39);
            this.APAGAR.Name = "APAGAR";
            this.APAGAR.Size = new System.Drawing.Size(84, 81);
            this.APAGAR.TabIndex = 14;
            this.APAGAR.Text = "APAGAR";
            this.APAGAR.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.APAGAR.UseVisualStyleBackColor = true;
            this.APAGAR.Click += new System.EventHandler(this.APAGAR_Click);
            // 
            // EDITAR
            // 
            this.EDITAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EDITAR.Image = global::FluxoCaixa.Properties.Resources.icons8_editar_48;
            this.EDITAR.Location = new System.Drawing.Point(371, 40);
            this.EDITAR.Name = "EDITAR";
            this.EDITAR.Size = new System.Drawing.Size(86, 80);
            this.EDITAR.TabIndex = 13;
            this.EDITAR.Text = "EDITAR";
            this.EDITAR.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.EDITAR.UseVisualStyleBackColor = true;
            this.EDITAR.Click += new System.EventHandler(this.EDITAR_Click);
            // 
            // BUSCAR
            // 
            this.BUSCAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUSCAR.Image = global::FluxoCaixa.Properties.Resources.icons8_pesquisar_mais_48;
            this.BUSCAR.Location = new System.Drawing.Point(267, 39);
            this.BUSCAR.Name = "BUSCAR";
            this.BUSCAR.Size = new System.Drawing.Size(89, 80);
            this.BUSCAR.TabIndex = 12;
            this.BUSCAR.Text = "BUSCAR";
            this.BUSCAR.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BUSCAR.UseVisualStyleBackColor = true;
            this.BUSCAR.Click += new System.EventHandler(this.BUSCAR_Click);
            // 
            // SALVAR
            // 
            this.SALVAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SALVAR.Image = global::FluxoCaixa.Properties.Resources.icons8_salvar_e_fechar_48;
            this.SALVAR.Location = new System.Drawing.Point(160, 40);
            this.SALVAR.Name = "SALVAR";
            this.SALVAR.Size = new System.Drawing.Size(90, 80);
            this.SALVAR.TabIndex = 11;
            this.SALVAR.Text = "SALVAR";
            this.SALVAR.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SALVAR.UseVisualStyleBackColor = true;
            this.SALVAR.Click += new System.EventHandler(this.SALVAR_Click);
            // 
            // ADD
            // 
            this.ADD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ADD.Image = global::FluxoCaixa.Properties.Resources.icons8_adicionar_48;
            this.ADD.Location = new System.Drawing.Point(51, 40);
            this.ADD.Name = "ADD";
            this.ADD.Size = new System.Drawing.Size(92, 80);
            this.ADD.TabIndex = 10;
            this.ADD.Text = "ADD";
            this.ADD.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.ADD.UseVisualStyleBackColor = true;
            this.ADD.Click += new System.EventHandler(this.ADD_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::FluxoCaixa.Properties.Resources.icons8_carrinho_de_compras_481;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Location = new System.Drawing.Point(280, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 53);
            this.button1.TabIndex = 15;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PRODUTOS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 455);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.APAGAR);
            this.Controls.Add(this.EDITAR);
            this.Controls.Add(this.BUSCAR);
            this.Controls.Add(this.SALVAR);
            this.Controls.Add(this.ADD);
            this.Controls.Add(this.txt_quant);
            this.Controls.Add(this.txt_marca);
            this.Controls.Add(this.txt_prod);
            this.Controls.Add(this.txt_preco);
            this.Controls.Add(this.txt_pesquisa);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "PRODUTOS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PRODUTOS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_pesquisa;
        private System.Windows.Forms.TextBox txt_preco;
        private System.Windows.Forms.TextBox txt_prod;
        private System.Windows.Forms.TextBox txt_marca;
        private System.Windows.Forms.TextBox txt_quant;
        private System.Windows.Forms.Button ADD;
        private System.Windows.Forms.Button SALVAR;
        private System.Windows.Forms.Button BUSCAR;
        private System.Windows.Forms.Button EDITAR;
        private System.Windows.Forms.Button APAGAR;
        private System.Windows.Forms.Button button1;
    }
}